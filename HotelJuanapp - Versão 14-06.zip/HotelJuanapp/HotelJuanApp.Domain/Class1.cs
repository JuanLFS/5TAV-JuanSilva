﻿using System;

namespace HotelJuanApp.Domain
{
    public class Class1
    {
    }
}
