﻿using System;

namespace HotelJuanApp.Infra.Data
{
    public class Class1
    {
    }
}
