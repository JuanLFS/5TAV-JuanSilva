﻿using System;

namespace HotelJuanApp.Infra.CrossCutting
{
    public class Class1
    {
    }
}
